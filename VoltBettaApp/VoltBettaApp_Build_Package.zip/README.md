# Volt Betta Manager App

This is the Volt Betta Manager application, packaged for local building.

## Quick Start

1. Extract all files from this zip archive
2. Follow the instructions in BUILD_INSTRUCTIONS.md to build the APK
3. Run `npm install` in this directory to install dependencies
4. Run `eas build --platform android --profile apk` to build with Expo Application Services

## Application Features

- Betta fish care management 
- Tank parameters tracking
- Maintenance scheduling
- Treatment plans
- Photo gallery
- Notes and observations

## Technical Details

This app is built with React Native and Expo, with a SQLite database for local storage.
The APK can be built using EAS CLI as detailed in the build instructions.

